<h1 align="center">
  <picture>
    <img align="center" alt="nextcloud" src="./logo.svg" height="40">
  </picture>
  Nextcloud
</h1>

- image version: nextcloud:25.0.4-apache
- [x] Accessible over http ?
- [x] Accessible over https ?
- [x] ARM v5 compatible ?
