export REPO_NAME="__APP_NAME__"
export DOMAIN="__APP_NAME__.$MAIN_DOMAIN"
export PORT="__PORT__"
export PORT_EXPOSED="3000"
export REDIRECTIONS="" # example.$MAIN_DOMAIN->/route $MAIN_DOMAIN->url /route->/another-route /route->url
