export REPO_NAME="nuxtci"
export DOMAIN="nuxtci.$MAIN_DOMAIN"
export PORT="7903"
export PORT_EXPOSED="3000"
