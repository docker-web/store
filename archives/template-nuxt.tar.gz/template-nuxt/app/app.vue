<template>
  <div>
    <NuxtRouteAnnouncer />
    <NuxtTemplate />
  </div>
</template>
