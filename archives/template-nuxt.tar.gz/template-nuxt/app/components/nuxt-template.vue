<template>
  <h1 class="flex gap-y-4 items-center justify-center flex items-center justify-center min-h-screen">
    <img src="/logo.svg" />
  </h1>
</template>
