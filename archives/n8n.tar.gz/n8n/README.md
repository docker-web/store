<h1 align="center">
  <picture>
    <img align="center" alt="n8n" src="./logo.svg" height="100">
  </picture>
  n8n
</h1>

- image version: n8nio/n8n
- [ ] Accessible over http ?
- [ ] Accessible over https ?
- [ ] ARM 64 compatible ?
