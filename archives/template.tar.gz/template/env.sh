export DOMAIN="APP-NAME.${MAIN_DOMAIN}"
export PORT="__PORT__"
export PORT_EXPOSED="80"
