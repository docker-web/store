<h1 align="center">
  <picture>
    <img align="center" alt="__APP_NAME__" src="./logo.svg" height="100">
  </picture>
  __APP_NAME__
</h1>

## BASE FILES

config.sh
docker-compose.yml
logo.svg

## EXTRA FILES

nginx.conf
post-install.sh
pre-install.sh

