<h1 align="center">
  <picture>
    <img align="center" alt="__APP_NAME__" src="./logo.svg" height="100">
  </picture>
  __APP_NAME__
</h1>
