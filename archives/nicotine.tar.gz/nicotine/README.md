<h1 align="center">
  <picture>
    <img align="center" alt="nicotine" src="./logo.svg" height="100">
  </picture>
  nicotine
</h1>

- image version: realies/nicotine
- [x] Accessible over http ?
- [x] Accessible over https ?
- [ ] ARM 64 compatible ?
