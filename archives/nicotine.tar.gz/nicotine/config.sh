export DOMAIN="nicotine.$MAIN_DOMAIN"
export PORT="7733"
export PORT_EXPOSED="8080"
export REDIRECTIONS=""
