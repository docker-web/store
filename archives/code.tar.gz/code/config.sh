export DOMAIN="code.$MAIN_DOMAIN"
export PORT="7745"
export PORT_EXPOSED="8443"
export REDIRECTIONS=""
