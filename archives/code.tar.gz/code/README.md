<h1 align="center">
  <picture>
    <img align="center" alt="Code" src="./logo.svg" height="40">
  </picture>
  Code
</h1>

- image version: latest linuxserver/code-server
- [x] Accessible over http ?
- [ ] Accessible over https ?
- [x] ARM 64 compatible ?
