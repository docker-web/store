export DOMAIN="slskd.$MAIN_DOMAIN"
export PORT="7712"
export PORT_EXPOSED="5030"
export REDIRECTIONS="" # example.$MAIN_DOMAIN->/route $MAIN_DOMAIN->url /route->/another-route /route->url
