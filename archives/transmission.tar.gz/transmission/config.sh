export DOMAIN="transmission.$MAIN_DOMAIN"
export PORT="9091"
export PORT_EXPOSED="9091"
export REDIRECTIONS=""
