<h1 align="center">
  <picture>
    <img align="center" alt="jellyfin" src="./logo.svg" height="40">
  </picture>
  Jellyfin
</h1>

- image version: jellyfin/jellyfin:10.8.9
- [x] Accessible over http ?
- [x] Accessible over https ?
- [x] ARM 64 compatible ?
- [] Pre create user
- [] Pre mount media folder
