<h1 align="center">
  <picture>
    <img align="center" alt="jellyfin" src="./logo.svg" height="40">
  </picture>
  Jellyfin
</h1>
