<h1 align="center">
  <picture>
    <img align="center" alt="docker-web" src="../../docs/docker-web.svg" height="40">
  </picture>
  Launcher
</h1>

- image version: nginx:1.23.2-alpine
- [x] Accessible over http ?
- [x] Accessible over https ?
- [x] ARM 64 compatible ?
