export DOMAIN="$MAIN_DOMAIN"
export PORT="7700"
export PORT_EXPOSED="80"
export REDIRECTIONS=""
export POST_INSTALL_TEST_CMD="pwd"
export LAUNCHER_HIDDEN=true
export ALIASES="map->map.$MAIN_DOMAIN youtube->www.youtube.com chatgpt->chatgpt.com whatsapp->web.whatsapp.com"
