export DOMAIN="ersatztv.$MAIN_DOMAIN"
export PORT="7847"
export PORT_EXPOSED="8409"
export REDIRECTIONS=""
export DOMAIN_TV="tv.$MAIN_DOMAIN"
export PORT_TV="7848"
export PORT_TV_EXPOSED="80"
export LAUNCHER_HIDDEN=true
