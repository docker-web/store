<h1 align="center">
  <picture>
    <img align="center" alt="ersatztv" src="./logo.svg" height="100">
  </picture>
  ersatztv
</h1>

## BASE FILES

config.sh
docker-compose.yml
logo.svg

## EXTRA FILES

nginx.conf
post-install.sh
pre-install.sh
