<h1 align="center">
  <picture>
    <img align="center" alt="ersatztv" src="./logo.svg" height="100">
  </picture>
  ersatztv
</h1>
