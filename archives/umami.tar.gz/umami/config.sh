export DOMAIN="umami.$MAIN_DOMAIN"
export PORT="7709"
export PORT_DB="7710"
export PORT_EXPOSED="3000"
