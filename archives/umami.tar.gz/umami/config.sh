export DOMAIN="umami.$MAIN_DOMAIN"
export PORT="7831"
export PORT_DB="7832"
export PORT_EXPOSED="3000"
export REDIRECTIONS="" # example.$MAIN_DOMAIN->/route $MAIN_DOMAIN->url /route->/another-route /route->url
