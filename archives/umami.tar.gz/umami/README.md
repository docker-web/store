<h1 align="center">
  <picture>
    <img align="center" alt="umami" src="./logo.svg" height="100">
  </picture>
  umami
</h1>

## BASE FILES

config.sh
docker-compose.yml
logo.svg

## EXTRA FILES

nginx.conf
post-install.sh
pre-install.sh

test docker run --network dockerweb -p 8181:8181 adminer
default uammi log/pass is admin/umami
