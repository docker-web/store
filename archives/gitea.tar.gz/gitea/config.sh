
#!/bin/bash
export DOMAIN="git.$MAIN_DOMAIN"
export PORT="7701"
export PORT_EXPOSED="3000"
