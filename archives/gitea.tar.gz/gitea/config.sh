
#!/bin/bash
export DOMAIN="git.$MAIN_DOMAIN"
export PORT="7722"
export PORT_EXPOSED="3000"

