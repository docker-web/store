#!/bin/bash

echo "drop flag 'disable-email-verification' after creating admin account"