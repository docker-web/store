export DOMAIN="penpot.$MAIN_DOMAIN"
export PORT="7904"
export PORT_EXPOSED="8080"
export SECRET_KEY="ThLzlxrKVVZF53kHGD57S9mHAkRCaJb67Oyl7kH7MdrcuPdUcmZ_BSkLBTEEiXx5hsxYlldHz_20yrIKMSITXw"
export REDIRECTIONS="" # example.$MAIN_DOMAIN->/route $MAIN_DOMAIN->url /route->/another-route /route->url
