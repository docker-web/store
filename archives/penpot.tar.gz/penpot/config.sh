export DOMAIN="penpot.$MAIN_DOMAIN"
export PORT="7904"
export PORT_EXPOSED="8080"
export SECRET_KEY=""
export REDIRECTIONS="" # example.$MAIN_DOMAIN->/route $MAIN_DOMAIN->url /route->/another-route /route->url
