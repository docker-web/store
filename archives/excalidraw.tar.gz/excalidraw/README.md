<h1 align="center">
  <picture>
    <img align="center" alt="excalidraw" src="./logo.svg" height="100">
  </picture>
  excalidraw
</h1>

- image version: excalidraw/excalidraw
- [ ] Accessible over http ?
- [ ] Accessible over https ?
- [ ] ARM 64 compatible ?

## BASE FILES

.drone.yml config.sh docker-compose.yml logo.svg nginx.conf post-install.sh pre-install.sh