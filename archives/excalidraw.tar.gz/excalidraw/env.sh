export DOMAIN="excalidraw.$MAIN_DOMAIN"
export PORT="7703"
export PORT_EXPOSED="80"
export REDIRECTIONS=""
