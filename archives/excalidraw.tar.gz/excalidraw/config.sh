export DOMAIN="excalidraw.$MAIN_DOMAIN"
export PORT="7823"
export PORT_EXPOSED="80"
export REDIRECTIONS=""
